const express = require('express');
const app = express();
const mongoose = require('mongoose');
mongoose.connect('mongodb+srv://aparna:P@11word@cluster0.ifkj9.mongodb.net/customerServive123?retryWrites=true&w=majority',{ useNewUrlParser: true ,useUnifiedTopology: true},()=>{
  console.log('Connecting to Database.....');
});
require('./CustomerModel');
const Customer = mongoose.model('Customer');
const bodyParser = require('body-parser');
app.use(bodyParser.json());

//mongodb+srv://<username>:<password>@cluster0.ifkj9.mongodb.net/<dbname>?retryWrites=true&w=majority
//customerServive123

app.post('/customer',(req,res)=>{
  const customerObj ={name: req.body.name,
  age: req.body.age,
address:req.body.address};
var customer = new Customer(customerObj);
customer.save().then(()=>{
  res.send('Success');
}).catch((err) =>{
  throw err;
});
});
app.get('/customer',(req,res)=>{
  Customer.find().then((customer) =>{res.json(customer)}).catch((err) =>{throw err});
});
app.get('/customer/:id',(req,res)=>{
  Customer.findById(req.params.id).then((customer) =>{res.send(customer)}).catch((err)=>{throw err;});
});
app.listen('4000',()=>{
  console.log('Listening to the port 4000');
});

const express  = require('express');
const app = express();
const mongoose= require('mongoose');
const axios = require('axios');
mongoose.connect('mongodb+srv://aparna:P@11word@cluster0.ifkj9.mongodb.net/OrderService123?retryWrites=true&w=majority',{ useNewUrlParser: true,useUnifiedTopology: true  },()=>{
  console.log('Connecting to Database......');
});
require('./OrderModel.js');
const Order = mongoose.model('Order');
const bodyParser = require('body-parser');

app.use(bodyParser.json());

app.post('/order',(req,res)=>{

var newOrderObj = {customerId:mongoose.Types.ObjectId(req.body.customerId),
  bookId:mongoose.Types.ObjectId(req.body.bookId),
  initialDate: req.body.initialDate,
  finalDate:req.body.finalDate
};
  var orderObj = new Order(newOrderObj);
  orderObj.save().then(()=>{res.send('Success');}).catch((err) =>{throw err});
});

app.get('/order/:id',(req,res)=>{

  Order.findById(req.params.id).then((order) =>{
    console.log(order);
  var orderObj ={name:' ',title:' '};
  axios.get('http://localhost:4000/customer/'+order.customerId).then((response)=>{
    orderObj.name = response.data.name;
    axios.get('http://localhost:4646/book/'+order.bookId).then((response)=>{
      orderObj.title = response.data.title;
      res.send(orderObj);
    })
  }
).catch((err)=>{throw err;});

}).catch((err) =>{throw err;});
});


app.get('/order',(req,res)=>{
  Order.find().then((order) =>{
    console.log(order);
    res.json(order);
  }).catch((err) =>{
    throw err;
  });
});



app.listen('5600',()=>{
  console.log('Listening to the port 5600');
});

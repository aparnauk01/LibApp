const mongoose = require('mongoose');
mongoose.model('Order',{
  customerId:{
    type:mongoose.Schema.ObjectId,
    require:true
  },
  bookId:{
    type:mongoose.Schema.ObjectId,
    require:true,
  },
  initialDate:{
    type:Date,
    require:true
  },
  finalDate:{
    type:Date,
    require:true
  }

});

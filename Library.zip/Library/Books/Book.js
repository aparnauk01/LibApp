const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
require("./BookModel");
const Book = mongoose.model('Book');
mongoose.connect('mongodb+srv://aparna:P@11word@cluster0.ifkj9.mongodb.net/bookservice123?retryWrites=true&w=majority',{ useUnifiedTopology: true,useNewUrlParser: true },() =>{
  console.log('Connecting to Db......');
});
app.use(bodyParser.json());

app.post('/book',async (req,res)=>{

  var newBodyObj ={title:req.body.title,
    author:req.body.author,
    numberPages:req.body.numberPages,
  publisher: req.body.publisher};
    var book =new Book(newBodyObj);
  var books1 = await  book.save();
  if(books1){res.send('Sent');}

});

app.get('/book',(req,res)=>{
  Book.find().then((book)=>{
    res.send(book);
  }).catch((err) =>{throw err;});
});

app.get('/book/:id',(req,res)=>{
  Book.findById(req.params.id).then((book)=>
  {  res.send(book);}
  ).catch((err) =>{
    throw err;
  });
});

app

app.listen(4646,() =>{
  console.log('Listening to port 4646......');
});
